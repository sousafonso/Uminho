{- |
Module      : Tarefa2_2022li1g096
Description : Geração contínua de um mapa
Copyright   : Rafael Correia <a104085@alunos.uminho.pt>
              Afonso Sousa <a104262@alunos.uminho.pt>

Módulo para a realização da Tarefa 2 do projeto de LI1 em 2022/23.
-}
module Tarefa2_2022li1g096 where

import LI12223
import System.Random

{-| A função 'estendeMapa' recebe um Mapa e uma /seed/ e retorna um mapa com uma linha de tipo @(Terreno, [Obstaculo])@ gerada aleatoriamente.
Esta função toma auxilio de outras funções como 'pick' ou 'chooseObstacles'.

==Exemplo de uso:
>>>estendeMapa (Mapa 5 []) (seed)
Mapa 5 [(Terreno, [Obstaculo])]    (nao ha como saber qual terreno ou qual a lista de obstaculos devido a aleatoriedade existente)


==Propriedades da função:

prop> estendeMapa (Mapa 5 [(Rio 0, l1), (Rio 0, l2), (Rio 0, l3), (Rio 0, l4)]) seed = Mapa 5 [(Rio 0 , l1), ..., (Rio 0, l4), (Estrada 0 || Relva, l5)]
-}

estendeMapa :: Mapa -> Int -> Mapa 
estendeMapa (Mapa y l) x = Mapa y (chooseMola j (w, chooseObstacles j y i (g, [])):l)
                                    where w = giveVel j q (pick j k)
                                          j = rng 0 100 (mkStdGen x)
                                          g = w
                                          k = proximosTerrenosValidos (Mapa y l)
                                          i = if null l then Nothing else Just (head l)
                                          q = if null l then Nothing else Just (fst(head l))

giveVel :: Int -> Maybe Terreno -> Terreno -> Terreno
giveVel j _ Relva = Relva
giveVel j _ (Estrada _) = Estrada v
                        where v = pick j [-1, -2, -3, 1, 2, 3]
giveVel j (Just (Rio v1)) (Rio _) | v1 < 0 = Rio v where v = pick j [1, 2, 3]
giveVel j (Just (Rio v2)) (Rio _) | v2 > 0 = Rio v where v = pick j [-1, -2, -3]
giveVel j _ (Rio _) = Rio v where v = pick j [-3, -2, -1, 1, 2, 3]



chooseMola :: Int -> (Terreno, [Obstaculo]) -> (Terreno, [Obstaculo])
chooseMola j (t, o) | t == Relva && (rng 0 100 (mkStdGen j)) <= 20 = (t, addMola j (auxMola 0 o []) o)
                    | otherwise = (t, o)

addMola :: Int -> [Int] -> [Obstaculo] -> [Obstaculo]                                      
addMola _ n l | n == [3, 2, 1] = l
addMola j n l = let (a, b:bs) = splitAt (pick j n) l
                   in a++[Mola]++bs

auxMola :: Int -> [Obstaculo] -> [Int] -> [Int]
auxMola _ [] _ = [3, 2, 1]
auxMola i (h:t) l | h == Nenhum = auxMola (i+1) t l++[i]
                  | otherwise = auxMola (i+1) t l

{-| A função 'proximosTerrenosValidos' retorna, quando recebido um 'Mapa', uma lista de 'Terrenos' que 
poderao ser usados numa proxima 'Linha' do 'Mapa' (de acordo com as restricoes dadas).

==Exemplos de uso:

>>>proximosTerrenosValidos (Mapa _ [(Rio 0, l1), (Rio 0, l2), (Rio 0, l3), (Rio 0, l4)])
[Relva, Estrada 0]  (ordem nao importante)

>>>proximosTerrenosValidos (Mapa _ [])
[Relva, Rio 0, Estrada 0]  (ordem nao importante)

-}

proximosTerrenosValidos :: Mapa -> [Terreno]
proximosTerrenosValidos (Mapa _ ((Relva, _):(Relva, _):(Relva, _):(Relva, _):(Relva, _):t)) = [Rio 0, Estrada 0] 
proximosTerrenosValidos (Mapa _ ((Estrada _, _):(Estrada _, _):(Estrada _, _):(Estrada _, _):(Estrada _, _):t)) = [Relva, Rio 0] 
proximosTerrenosValidos (Mapa _ ((Rio _, _):(Rio _, _):(Rio _, _):(Rio _, _):t)) = [Relva, Estrada 0] 
proximosTerrenosValidos (Mapa _ l) = [Relva, Rio 0, Estrada 0] 
{-|Auxiliar da funcao 'proximosTerrenosValidos', quando 'vel valida' recebe uma 'Mapa',
devolve uma velocidade adequada de um 'Rio'.
-}
velValida :: [(Terreno, [Obstaculo])] -> Int -> Int
velValida ((Rio v, _):t) j | v > 0 = pick j [-3, -2, -1]
                           | otherwise = pick j [1, 2, 3]
velValida _ j = pick j [-3, -2, -1, 1, 2, 3]

{-|Esta função, 'chooseObstacles' é usada na função principal 'estendeMapa' e recebe a seed dessa função, usando-a para construir uma lista de obstaculos aleatoria
que obedece as restricoes dadas. Tira proveito da função 'proximosObstaculosValidos'.

==Propiedade importante da função:

prop>chooseObstacles seed 5 (Relva, [Arvore, Arvore, Arvore, Arvore]) = [Arvore, Arvore, Arvore, Arvore, Nenhum]
-}
chooseObstacles :: Int -> Int -> Maybe (Terreno, [Obstaculo]) -> (Terreno, [Obstaculo]) -> [Obstaculo]
chooseObstacles j y (Just (t, o)) (w, l) | t == Relva && t == w = let p = makeObstList (rng 0 100 (mkStdGen j)) y (w, l)
                                                           in changeObst j (aux 0 0 [] o p) p 
chooseObstacles j y _ (w, l) = makeObstList j y (w, l)

makeObstList :: Int -> Int -> (Terreno, [Obstaculo]) -> [Obstaculo]                                --Generates random [Obstaculo]
makeObstList j y (w, l) | y > length l = makeObstList (rng 0 100 (mkStdGen j)) y (w, l ++ k)
                        | otherwise = l
                        where k = [pick j (proximosObstaculosValidos y (w, l))]

changeObst :: Int -> [Int] -> [Obstaculo] -> [Obstaculo]                                           --Changes specific elements to 'Nenhum' if necessary (if no 'Nenhum's seguidos)
changeObst _ n l | n == [3, 2, 1] = l
changeObst j n l = let (a, b:bs) = splitAt (pick j n) l
                   in a++[Nenhum]++bs

aux :: Int -> Int -> [Int] -> [Obstaculo] -> [Obstaculo] -> [Int]                                  --Aux de changeObst (retorna uma lista dos indices dos 'Nenhum's da [Obstaculo] caso nao haja 'Nenhum's seguidos)
aux x y z o _ | null o && y > 0 = [3, 2, 1]   --specific 'pin' for "no need to change the list"
              | null o && y == 0 = z
aux x y z (h:t) (h1:t1) | h == Nenhum && h1 == Nenhum = aux (x+1) (y+1) (z++[x]) t t1
                        | h == Nenhum = aux (x+1) y (z++[x]) t t1
                        | otherwise = aux (x+1) y z t t1

{-|A função 'proximosObstaculosValidos' recebe um @Inteiro@ e um tuplo @(Terreno, [Obstaculo])@, e retorna uma lista dos proximos obstaculos possiveis dadas as restricoes.
Toma proveito da função 'countObstaculos'.

==Exemplo de uso:

>>>proximosObstaculosValidos 5 (Relva, [Nenhum])
[Arvore, Nenhum]

==Propriedades da função:

prop>proximosObstaculosValidos 1 (_, []) = [Nenhum] (Caso o mapa tenha 1 de largura, vai sempre retornar [Nenhum])

prop>proximosObstaculosValidos 3 (Relva, [Arvore, Arvore]) = [Nenhum]  (Se so se puder adicionar mais 1 obstaculo, caso nao haja nenhum "Nenhum" na lista, tem de retornar [Nenhum])

-}
proximosObstaculosValidos :: Int -> (Terreno, [Obstaculo]) -> [Obstaculo]
proximosObstaculosValidos z (_, l) | z == length l = []
                                   | notElem Nenhum l && length l == z - 1 = [Nenhum]
proximosObstaculosValidos z (Relva, l) | notElem Arvore l && length l == z - 1 = [Arvore]
proximosObstaculosValidos z (Rio _, l) | notElem Tronco l && length l == z -1 = [Tronco]
proximosObstaculosValidos z (Estrada _, l)| notElem Carro l && length l == z -1 = [Carro]
proximosObstaculosValidos  _ k = countObstaculos 0 0 k

{-|A função 'countObstaculos' conta quantos obstaculos seguidos se encontram no fim da lista de obstaculos dada. Caso haja, p.e., 5 "Tronco" seguidos, irá retornar [Nenhum].
É auxiliar da função 'proximosObstaculosValidos'.

==Propriedades da função:

prop>countObstaculos 0 0 (Relva, _) = [Arvore, Nenhum]
prop>countObstaculos 0 0 (Rio _, [Tronco, Tronco, Tronco, Tronco, Tronco]) = [Nenhum]
prop>countObstaculos 0 0 (Estrada _, [Carro, Carro, Carro]) = [Nenhum]
-}
countObstaculos :: Int -> Int -> (Terreno, [Obstaculo]) -> [Obstaculo]
countObstaculos _ _ (Relva, _) = [Arvore, Nenhum]
countObstaculos t c (k, x:xs) | x == Tronco = countObstaculos (t+1) 0 (k, xs)
                              | x == Carro = countObstaculos 0 (c+1) (k, xs)
                              | otherwise = countObstaculos 0 0 (k, xs)
countObstaculos t c (k, []) | t >= 5 = [Nenhum]
                            | c >= 3 = [Nenhum]
countObstaculos t c (Rio _, []) = [Tronco, Nenhum]
countObstaculos t c (Estrada _, []) = [Carro, Nenhum]

{-|A função 'rng' , dado um minimo "x", um maximo "y", e uma /seed/ "j", gera um numero aleatorio entre "x" e "y".
-}
rng :: (RandomGen g) => Int -> Int -> g -> Int
rng x y j = fst (randomR (x, y) j) 

{-|Recebido uma /seed/ "j" e uma lista de tipo qualquer "l", 'pick' escolhe um elemento de "l" aleatoriamente. Usa a função 'rng'.
-}
pick :: Int -> [a] -> a
pick j l | j > length l -1 = l !! rng 0 w (mkStdGen j)
         | otherwise = l !! j
          where w = length l - 1

coin :: Int -> Bool
coin j = pick j [0, 1] == 1

change :: Int -> Int -> Int -> Int
change j x z | coin j = z
             | otherwise = x