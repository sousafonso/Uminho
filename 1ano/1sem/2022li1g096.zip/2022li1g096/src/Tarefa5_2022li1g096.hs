
module Tarefa5_2022li1g096 where
    
import LI12223 
import Tarefa2_2022li1g096
import System.Random

deslizaJogo :: Int -> Jogo -> Jogo
deslizaJogo j (Jogo (Jogador (x, y)) map) = Jogo (Jogador (x, y+1)) (estendeMapa map j)