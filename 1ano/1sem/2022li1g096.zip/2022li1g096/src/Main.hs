
module Main where

import LI12223
import Tarefa1_2022li1g096
import Tarefa2_2022li1g096
import Tarefa3_2022li1g096
import Tarefa4_2022li1g096
import Tarefa5_2022li1g096
import Graphics.Gloss
import Graphics.Gloss.Interface.Pure.Game
import Graphics.Gloss.Interface.IO.Game
import System.Exit
import System.Directory
import System.Random
import GHC.Base (VecElem(Int16ElemRep))
import GHC.IO.Encoding.Failure (CodingFailureMode(TransliterateCodingFailure))
import GHC.Read (readField)

data Opcao = Jogar
            | Continuar
            | SairJogo

data Diff = Facil 
            | Medio
            | Dificil
            | Endless

data PauseMenu = Resume
                | Save
                | Quit

-- type Estado = (Coordenadas, Imagens)

data Menu = Opcoes Opcao
            | DiffSelect Diff
            | ModoJogo
            | VenceuJogo
            | PerdeuJogo
            | Pausa PauseMenu 

type Images = [Picture]

type World = (Menu, Jogo, (Diff, Int))  -- Este Diff e Int guardam a dificuldade e score em qualquer tipo de Menu

type WorldGloss = (World, Images, Int, Int)  -- ESTE INT E UMA SEED ALEATORIA GERADA QUANTO SE INICIA O JOGO O SEGUNDO INT REPRESENTA O TEMPO

instance Show Diff where
    show Facil = show "Facil"
    show Medio = show "Medio"
    show Dificil = show "Dificil"
    show Endless = show "Endless"

data Imagens = 
  Imagens
    { playerI :: Picture,
      troncoI :: Picture,
      arvoreI :: Picture,
      rioI :: Picture,
      carroI1 :: Picture,    -- carro com sentido da esquerda para a direita (+)
      carroI2 :: Picture,    -- carro com sentido da direita para a esquerda (-)
      estradaI :: Picture,
      relvaI :: Picture,
      moedaI :: Picture,
      molaI :: Picture
    }
    deriving Show

{- | A função 'desenhaJogador' desenha o jogador 
-} 
desenhaJogador :: Images -> Jogador -> Picture                        --TEMPORARIAMENTE O PLAYER VAI SER CIRCULO PRETO PARA TESTES
desenhaJogador images (Jogador (x, y)) = Translate ((i-5)*100) ((j-3)*(-100)) $  playerI
                                      where i = fromIntegral x
                                            j = fromIntegral y
                                            [playerI, arvoreI, troncoI, carroI1, carroI2, relvaI, rioI, estradaI, moedaI, molaI] = images
                                            

{- | A função 'desenhaMapa' é responsável por desenhar o mapa como o próprio nome indica
-}

desenhaMap :: Images -> Mapa -> Int -> Picture -> Picture
desenhaMap images (Mapa lar (h:t)) i (Pictures lp) = desenhaMap images (Mapa lar t) (i+1) (Pictures (lp ++ [Translate 0 j $ desenhaLine images h])) where j = ((w-3)*100)*(-1)
                                                                                                                                                          w = fromIntegral i
desenhaMap _ (Mapa _ []) _ (Pictures lp) = Pictures lp

desenhaLine :: Images -> (Terreno, [Obstaculo]) -> Picture
desenhaLine images (Estrada v, o) = Pictures ([desenhaTerreno images (Estrada v)]++[desenhaObst 0 v (Estrada v) o images (Pictures [])])
desenhaLine images (ter, o) = Pictures ([desenhaTerreno images (ter)]++[desenhaObst 0 0 ter o images (Pictures [])])

desenhaTerreno :: Images -> Terreno -> Picture
desenhaTerreno images Relva = Pictures [Translate (-500) 0 $ relvaI, Translate (-400) 0 $ relvaI, Translate (-300) 0 $ relvaI, Translate (-200) 0 $ relvaI, Translate (-100) 0 $ relvaI, Translate 0 0 $ relvaI, Translate (100) 0 $ relvaI, Translate (200) 0 $ relvaI, Translate (300) 0 $ relvaI, Translate (400) 0 $ relvaI, Translate (500) 0 $ relvaI]   where [playerI, arvoreI, troncoI, carroI1, carroI2, relvaI, rioI, estradaI, moedaI, molaI] = images
desenhaTerreno images (Rio v) = Pictures [Translate (-500) 0 $ rioI, Translate (-400) 0 $ rioI, Translate (-300) 0 $ rioI, Translate (-200) 0 $ rioI, Translate (-100) 0 $ rioI, Translate 0 0 $ rioI, Translate (100) 0 $ rioI, Translate (200) 0 $ rioI, Translate (300) 0 $ rioI, Translate (400) 0 $ rioI, Translate (500) 0 $ rioI]   where [playerI, arvoreI, troncoI, carroI1, carroI2, relvaI, rioI, estradaI, moedaI, molaI] = images
desenhaTerreno images (Estrada v) = Pictures [Translate (-500) 0 $ estradaI, Translate (-400) 0 $ estradaI, Translate (-300) 0 $ estradaI, Translate (-200) 0 $ estradaI, Translate (-100) 0 $ estradaI, Translate 0 0 $ estradaI, Translate (100) 0 $ estradaI, Translate (200) 0 $ estradaI, Translate (300) 0 $ estradaI, Translate (400) 0 $ estradaI, Translate (500) 0 $ estradaI]   where [playerI, arvoreI, troncoI, carroI1, carroI2, relvaI, rioI, estradaI, moedaI, molaI] = images

desenhaObst :: Int -> Int -> Terreno -> [Obstaculo] -> Images -> Picture -> Picture    --APENAS PARA TESTAR SE O JOGO FUNCIONA, POUCO EFICIENTE 
desenhaObst i v Relva (h:t) images (Pictures lp) | h == Arvore = desenhaObst (i+1) v Relva t images (Pictures (lp ++ [Translate ((j*100)-5) 20 $ arvoreI]))
                                                 | h == Mola = desenhaObst (i+1) v Relva t images (Pictures (lp ++ [Translate ((j*100)-5) 20 $ molaI]))
                                                 | otherwise = desenhaObst (i+1) v Relva t images (Pictures lp)
                                                         where j = fromIntegral (i-5)  --CASO SEJA EM RELVA
                                                               [playerI, arvoreI, troncoI, carroI1, carroI2, relvaI, rioI, estradaI, moedaI, molaI] = images


desenhaObst i v (Estrada ve) (h:t) images (Pictures lp) | h == Carro = desenhaObst (i+1) v (Estrada ve) t images (Pictures (lp ++ [Translate (j*100) 0 $ car])) 
                                                        | otherwise = desenhaObst (i+1) v (Estrada ve) t images (Pictures lp) 
                                                         where j = fromIntegral (i-5)  --CASO SEJA EM ESTRADA
                                                               [playerI, arvoreI, troncoI, carroI1, carroI2, relvaI, rioI, estradaI, moedaI, molaI] = images
                                                               car = if v>0 then carroI1 else carroI2

desenhaObst i v (Rio ve) (h:t) images (Pictures lp) | h == Tronco = desenhaObst (i+1) v (Rio ve) t images (Pictures (lp ++ [Translate (j*100) 0 $ troncoI]))    
                                                    | otherwise = desenhaObst (i+1) v (Rio ve) t images (Pictures lp)
                                                          where j = fromIntegral (i-5)  --CASO SEJA EM RIO
                                                                [playerI, arvoreI, troncoI, carroI1, carroI2, relvaI, rioI, estradaI, moedaI, molaI] = images
desenhaObst _ _ _ [] _  (Pictures lp)= Pictures (lp)


estendeBy :: Int -> Mapa -> Int -> Mapa
estendeBy n map j | n > 0 = estendeBy (n-1) (estendeMapa map j) (j+1)
                  | otherwise = map

{- | A função 'checkWin', como o próprio nome indica, evidencia quando um jogador ganha um jogo dependendo do modo de jogo
-}

checkWin :: World -> Bool    -- verificar se um jogo foi ganho (quando se chega a um score, endless nao termina)
checkWin (ModoJogo, j, (Facil, i)) | i == 20 = True
checkWin (ModoJogo, j, (Medio, i)) | i == 40 = True -- i -> Score (Pode ser alterado o score de vitoria aqui)
checkWin (ModoJogo, j, (Dificil, i)) | i == 60 = True
checkWin w = False


-- no caso de menu principal
desenhaEstado :: WorldGloss -> IO Picture
desenhaEstado ((PerdeuJogo, jogo, ds), p, j, s) = return (Pictures [Color red $ Translate (-185) 0 $ Scale 0.5 0.5 $ Text "YOU LOST !", Color orange $ Translate (-390) (-105) $ Scale 0.3 0.3 $ Text "Pressiona Enter para comecar um novo jogo"])
desenhaEstado ((VenceuJogo, jogo, ds), p, j, s) = return (Color green $ Scale 0.5 0.5 $ Text "YOU WON!")
desenhaEstado ((Opcoes Jogar, jogo, ds), p, j, s) = return (Pictures [Color orange $ Translate 0 30 $ Scale (0.2) (0.2) $ Text "Jogar", Color white $ Translate 0 0 $ Scale (0.2) (0.2) $ Text "Continuar", Color white $ Translate 0 (-30) $ Scale (0.2) (0.2) $ Text "Sair"])
desenhaEstado ((Opcoes Continuar, jogo, ds), p, j, s) = return (Pictures [Color white $ Translate 0 30 $ Scale (0.2) (0.2) $ Text "Jogar", Color orange $ Translate 0 0 $ Scale (0.2) (0.2) $ Text "Continuar", Color white $ Translate 0 (-30) $ Scale (0.2) (0.2) $ Text "Sair"])
desenhaEstado ((Opcoes SairJogo, jogo, ds), p, j, s) = return (Pictures [Color white $ Translate 0 30 $ Scale (0.2) (0.2) $ Text "Jogar", Color white $ Translate 0 0 $ Scale (0.2) (0.2) $ Text "Continuar", Translate 0 (-30) $ Color orange $ Scale (0.2) (0.2) $ Text "Sair"])

--no caso de DiffSelect
desenhaEstado ((DiffSelect Facil, jogo, ds), p, j, s) = return (Pictures [Translate (0) (60) $ Scale (0.2) (0.2) $ Color blue $ desenhaDiff "Facil", Color white $ Translate (0)(20) $ Scale (0.2) (0.2) $ desenhaDiff "Medio", Color white $ Translate (0) (-20) $ Scale (0.2) (0.2) $ desenhaDiff "Dificil", Color white $ Translate (0)(-60) $ Scale (0.2) (0.2) $ desenhaDiff "Endless"])
desenhaEstado ((DiffSelect Medio, jogo, ds), p, j, s) = return (Pictures [Color white $ Translate (0) (60) $ Scale (0.2) (0.2) $ desenhaDiff "Facil", Translate (0)(20) $ Scale (0.2) (0.2) $ Color blue $ desenhaDiff "Medio", Color white $ Translate (0) (-20) $ Scale (0.2) (0.2) $  desenhaDiff "Dificil", Color white $ Translate (0)(-60) $ Scale (0.2) (0.2) $ desenhaDiff "Endless"])
desenhaEstado ((DiffSelect Dificil, jogo, ds), p, j, s) = return (Pictures [Color white $ Translate (0) (60) $ Scale (0.2) (0.2) $ desenhaDiff "Facil", Color white $ Translate (0)(20) $ Scale (0.2) (0.2) $ desenhaDiff "Medio", Translate (0) (-20) $ Scale (0.2) (0.2) $ Color blue $  desenhaDiff "Dificil", Color white $ Translate (0)(-60) $ Scale (0.2) (0.2) $ desenhaDiff "Endless"])
desenhaEstado ((DiffSelect Endless, jogo, ds), p, j, s) = return (Pictures [Color white $ Translate (0) (60) $ Scale (0.2) (0.2) $ desenhaDiff "Facil", Color white $ Translate (0)(20) $ Scale (0.2) (0.2) $ desenhaDiff "Medio", Color white $ Translate (0) (-20) $ Scale (0.2) (0.2) $ desenhaDiff "Dificil", Translate (0)(-60) $ Scale (0.2) (0.2) $ Color blue $ desenhaDiff "Endless"])

-- em pausa
desenhaEstado ((Pausa Resume, jogo, ds), p, j, s) = return (Pictures [Translate 0 30 $ Color yellow $ Scale 0.2 0.2 $ Text "Resume",  Color orange $ Scale 0.2 0.2 $ Text "Save", Translate 0 (-30) $ Color orange $ Scale 0.2 0.2 $ Text "Quit"])
desenhaEstado ((Pausa Save, jogo, ds), p, j, s) = return (Pictures [Translate 0 30 $ Color orange $ Scale 0.2 0.2 $ Text "Resume",  Color yellow $ Scale 0.2 0.2 $ Text "Save", Translate 0 (-30) $ Color orange $ Scale 0.2 0.2 $ Text "Quit"])
desenhaEstado ((Pausa Quit, jogo, ds), p, j, s) = return (Pictures [Translate 0 30 $ Color orange $ Scale 0.2 0.2 $ Text "Resume",  Color orange $ Scale 0.2 0.2 $ Text "Save", Translate 0 (-30) $ Color yellow $ Scale 0.2 0.2 $ Text "Quit"])

--EM JOGO

desenhaEstado ((ModoJogo, Jogo jogador mapa, (_, score)), images, j, s) = return (Pictures ([desenhaMap images mapa 0 (Pictures [])]++[desenhaJogador images jogador]++[desenhaScore score]))

{- | A função 'desenhaScore' é responsável por apresentar o score do jogador -}
desenhaScore :: Int -> Picture
desenhaScore s = Translate 500 300 $ Scale 0.3 0.3 $ Text (show s)


desenhaDiff diff = Text diff

desenhaOpcao :: String -> Picture
desenhaOpcao op = Text op


{-
tempo :: Float -> WorldGloss -> IO WorldGloss
--CASO O MAPA SEJA MUITO CURTO (com 1 ou mais linhas a menos) GERA NOVAS LINHAS ALEATORIAS
tempo n world@((ModoJogo, (Jogo (player) (Mapa lar linhas)), ds), p) | mod (round (n*100)) 83 == 0 = return ((ModoJogo, deslizaJogo (round n) (Jogo (player) (Mapa lar linhas)) , ds), p)

tempo n world@((ModoJogo, (Jogo (player) (Mapa lar linhas)), ds), p) | length linhas < 7 = return ((ModoJogo, (Jogo (player) (estendeBy (7-(length linhas)) (Mapa lar linhas) (round (n*1000)))), ds), p)
                                                                     | length linhas > 7 = return ((ModoJogo, (Jogo (player) (Mapa lar (take 7 linhas))), ds), p)
                                                                     | otherwise = return world

tempo n world@((ModoJogo, (Jogo (player) (Mapa lar linhas)), ds), p) | mod (round n) 1000 == 0 = return ((ModoJogo, animaJogo (Jogo (player) (Mapa lar linhas)) Parado, ds), p)
                                                                     | otherwise = return world
-}

tempo :: Float -> WorldGloss -> IO WorldGloss
tempo seconds ((ModoJogo, jogo, ds), p, j, time)        | jogoTerminou jogo = return ((PerdeuJogo, jogo, ds), p, j, (time+(round (seconds*1000)))) 
                                                        | checkWin (ModoJogo, jogo, ds) = return ((VenceuJogo, jogo, ds), p, j, (time+(round (seconds*1000))))
                                                        | mod time 2000 == 0 = do r <- randomRIO (0, 10000) :: IO Int 
                                                                                  return ((ModoJogo, animaJogo (deslizaJogo j jogo) Parado, ds), p, r, (time+(round (seconds*1000))))
                                                        | mod time 800 == 0 =  do r <- randomRIO (0, 10000) :: IO Int
                                                                                  return ((ModoJogo, animaJogo jogo Parado, ds), p, r, (time+(round (seconds*1000))))
                                                        | otherwise = do r <- randomRIO (0, 10000) :: IO Int 
                                                                         return ((ModoJogo, jogo, ds), p, j, (time+(round (seconds*1000))))

tempo _ w = return w
{- | A função 'estadoInicial' é responsável por definir a estância inicial do jogo
-}
estadoInicial :: World
estadoInicial = (Opcoes Jogar, Jogo (Jogador (5, 4)) mapa, (Facil, 0))
                                where mapa = Mapa 11 [
                                        (Relva, [Arvore, Arvore, Arvore, Nenhum, Nenhum, Nenhum, Nenhum, Nenhum, Arvore, Arvore, Arvore]),
                                        (Relva, [Arvore, Arvore, Arvore, Nenhum, Nenhum, Nenhum, Nenhum, Nenhum, Arvore, Arvore, Arvore]),
                                        (Relva, [Arvore, Arvore, Arvore, Nenhum, Nenhum, Nenhum, Nenhum, Nenhum, Arvore, Arvore, Arvore])
                                        ]

estadoInicialGloss :: World -> [Picture] -> Int -> IO WorldGloss
estadoInicialGloss ((mode, Jogo player mapa, ds)) images j = do r <- randomRIO (0, 1000) :: IO Int 
                                                                return ((mode, Jogo player (estendeBy 4 mapa r), ds), images, j, 0)

{- | A função 'evento' permite animar o jogo consoante ações tomadas pelo jogador 
-}
evento :: Event -> WorldGloss -> IO WorldGloss
-- Menu 
evento (EventKey (SpecialKey KeyEnter) Down _ _) ((Opcoes Jogar, jogo, ds), p, j, s) = return ((DiffSelect Facil, jogo, ds), p, j, s)
evento (EventKey (SpecialKey KeyEnter) Down _ _) ((Opcoes SairJogo, jogo, ds), p, j, s) = do exitSuccess

--Quando Jogar
evento (EventKey (SpecialKey KeyUp) Down _ _) ((Opcoes Jogar, jogo, ds), p, j, s) = return ((Opcoes SairJogo, jogo, ds), p, j, s)
evento (EventKey (SpecialKey KeyDown) Down _ _) ((Opcoes Jogar, jogo, ds), p, j, s) = return ((Opcoes Continuar, jogo, ds), p, j, s)

--Quando Continuar
evento (EventKey (SpecialKey KeyUp) Down _ _) ((Opcoes Continuar, jogo, ds), p, j, s) = return ((Opcoes Jogar, jogo, ds), p, j, s)
evento (EventKey (SpecialKey KeyDown) Down _ _) ((Opcoes Continuar, jogo, ds), p, j, s) = return ((Opcoes SairJogo, jogo, ds), p, j, s)

--Quando Sair
evento (EventKey (SpecialKey KeyUp) Down _ _) ((Opcoes SairJogo, jogo, ds), p, j, s) = return ((Opcoes Continuar, jogo, ds), p, j, s)
evento (EventKey (SpecialKey KeyDown) Down _ _) ((Opcoes SairJogo, jogo, ds), p, j, s) = return ((Opcoes Jogar, jogo, ds), p, j, s)

-- Selecionar Dificuldade
evento (EventKey (SpecialKey KeyEnter) Down _ _) ((DiffSelect Facil, jogo, _), p, j, s) = return ((ModoJogo, jogo, (Facil, 0)), p, j, s)
evento (EventKey (SpecialKey KeyEnter) Down _ _) ((DiffSelect Medio, jogo, _), p, j, s) = return ((ModoJogo, jogo, (Medio, 0)), p, j, s)
evento (EventKey (SpecialKey KeyEnter) Down _ _) ((DiffSelect Dificil, jogo, _), p, j, s) = return ((ModoJogo, jogo, (Dificil, 0)), p, j, s)
evento (EventKey (SpecialKey KeyEnter) Down _ _) ((DiffSelect Endless, jogo, _), p, j, s) = return((ModoJogo, jogo, (Endless, 0)), p, j, s)
--quando Facil
evento (EventKey (SpecialKey KeyUp) Down _ _) ((DiffSelect Facil, jogo, ds), p, j, s) = return ((DiffSelect Endless, jogo, ds), p, j, s)
evento (EventKey (SpecialKey KeyDown) Down _ _ ) ((DiffSelect Facil, jogo, ds), p, j, s) = return ((DiffSelect Medio, jogo, ds), p, j, s)
--quando Medio
evento (EventKey (SpecialKey KeyUp) Down _ _) ((DiffSelect Medio, jogo, ds), p, j, s) = return ((DiffSelect Facil, jogo, ds), p, j, s)
evento (EventKey (SpecialKey KeyDown) Down _ _) ((DiffSelect Medio, jogo, ds), p, j, s) = return ((DiffSelect Dificil, jogo, ds), p, j, s)
--quando Dificil
evento (EventKey (SpecialKey KeyUp) Down _ _) ((DiffSelect Dificil, jogo, ds), p, j, s) = return ((DiffSelect Medio, jogo, ds), p, j, s)
evento (EventKey (SpecialKey KeyDown) Down _ _) ((DiffSelect Dificil, jogo, ds), p, j, s) = return ((DiffSelect Endless, jogo, ds), p, j, s)
--quando Endless
evento (EventKey (SpecialKey KeyUp) Down _ _) ((DiffSelect Endless, jogo, ds), p, j, s) = return ((DiffSelect Dificil, jogo, ds), p, j, s)
evento (EventKey (SpecialKey KeyDown) Down _ _) ((DiffSelect Endless, jogo, ds), p, j, s) = return ((DiffSelect Facil, jogo, ds), p, j, s)

--se numa mola saltar quando carrega no espaco
evento (EventKey (SpecialKey KeySpace) Down _ _) w@((ModoJogo, (Jogo (Jogador (x, y)) (Mapa l ll)), ds), p, j, s) | o!!x == Mola = return ((ModoJogo, Jogo (Jogador (x, y-3)) (Mapa l ll), ds), p, j, s)
                                                                                                                  | otherwise = return w
                                                                                                                  where (t, o) = ll!!y


-- Para pausar o Jogo 
evento (EventKey (Char 'p') Down _ _) ((ModoJogo, jogo, ds), p, j, s) = return ((Pausa Resume, jogo, ds), p, j, s)   --   d <-- dificuldade       s <-- score

--escolher opcoes dentro do Menu de Pausa
evento (EventKey (SpecialKey KeyUp) Down _ _) ((Pausa Resume, jogo, ds), p, j, s) = return ((Pausa Quit, jogo, ds), p, j, s)
evento (EventKey (SpecialKey KeyDown) Down _ _) ((Pausa Resume, jogo, ds), p, j, s) = return ((Pausa Save, jogo, ds), p, j, s)

evento (EventKey (SpecialKey KeyUp) Down _ _) ((Pausa Save, jogo, ds), p, j, s) = return ((Pausa Resume, jogo, ds), p, j, s)
evento (EventKey (SpecialKey KeyDown) Down _ _) ((Pausa Save, jogo, ds), p, j, s) = return ((Pausa Quit, jogo, ds), p, j, s)

evento (EventKey (SpecialKey KeyUp) Down _ _) ((Pausa Quit, jogo, ds), p, j, s) = return ((Pausa Save, jogo, ds), p, j, s)
evento (EventKey (SpecialKey KeyDown) Down _ _) ((Pausa Quit, jogo, ds), p, j, s) = return ((Pausa Resume, jogo, ds), p, j, s)

--Salvar o jogo no menu de pausa
evento (EventKey (SpecialKey KeyEnter) Down _ _) ((Pausa Save, jogo,ds), p, j, s) = do
            writeFile "save.txt" (show (jogo, ds))
            return ((Pausa Save, jogo, ds), p, j, s)
--Resumir o jogo
evento (EventKey (SpecialKey KeyEnter) Down _ _) ((Pausa Resume, jogo, ds), p, j, s) = return ((ModoJogo, jogo, ds), p, j, s)
--Dar quit ao jogo
evento (EventKey (SpecialKey KeyEnter) Down _ _) ((Pausa Quit, jogo, ds), p, j, s) = do exitSuccess

--Ao perder ou vencer carregar no enter para recomecar
evento (EventKey (SpecialKey KeyEnter) Down _ _) ((PerdeuJogo, jogo, ds), p, j, s) = do 
                                                                                      r <- randomRIO (0, 1000) :: IO Int
                                                                                      estadoInicialGloss (estadoInicial) p r
evento (EventKey (SpecialKey KeyEnter) Down _ _) ((VenceuJogo, jogo, ds), p, j, s) = do 
                                                                                      r <- randomRIO (0, 1000) :: IO Int
                                                                                      estadoInicialGloss (estadoInicial) p r

-- Comandos (incompleto)
evento (EventKey (SpecialKey KeyUp) Down _ _) ((ModoJogo, jogo, (d, score)), p, j, s) = return ((ModoJogo, animaPlayer jogo (Move Cima), (d, atualizaScore score jogo (Move Cima))), p, j, s)
evento (EventKey (SpecialKey KeyDown) Down _ _) ((ModoJogo, jogo, (d, score)), p, j, s) = return ((ModoJogo, animaPlayer jogo (Move Baixo), (d, atualizaScore score jogo (Move Baixo))), p, j, s)
evento (EventKey (SpecialKey KeyRight) Down _ _) ((ModoJogo, jogo, ds), p, j, s) = return ((ModoJogo, animaPlayer jogo (Move Direita), ds), p, j, s)
evento (EventKey (SpecialKey KeyLeft) Down _ _) ((ModoJogo, jogo, ds), p, j, s) = return ((ModoJogo, animaPlayer jogo (Move Esquerda), ds), p, j, s)

evento _ s = return s -- ignora qualquer outro evento

{- | A função 'window' dimensiona o jogo 
-}
window :: Display
window = InWindow
            "CrossyRoad"  -- titulo da janela
            (1100, 700)    -- dimensao da janela
            (0, 0)        -- posição no ecrã

{- | A função 'bg' define o "background" (fundo) do jogo
-}
bg :: Color
bg = black

{- | A função 'loadSave' é responsável por guardar dados relativos ao jogo 
-}
loadSave :: IO Jogo
loadSave = do
    doesExist <- doesFileExist "save.txt"
    saved <- if doesExist then readFile "save.txt"
                else return ("Jogo (Jogador (0, 0)) (Mapa 7 [])")
    return (read saved)

fr :: Int
fr = 50

main :: IO ()
main = do
        j <- randomRIO (0, 10000) :: IO Int
        
        player   <- loadBMP "player.bmp"
        arvore   <- loadBMP "arvore.bmp"
        tronco   <- loadBMP "tronco.bmp"
        carro1   <- loadBMP "carroI1.bmp"
        carro2   <- loadBMP "carroI2.bmp"
        relvaI   <- loadBMP "relva.bmp"
        rio      <- loadBMP "rio.bmp"
        estrada  <- loadBMP "estrada.bmp"
        moedaI   <- loadBMP "moeda.bmp"
        mola    <- loadBMP "mola.bmp"

        let images = [playerI, arvoreI, troncoI, carroI1, carroI2, relvaI, rioI, estradaI, moedaI, molaI]
            playerI  = Translate 35 20 $ scale 0.14 0.14 player
            arvoreI  = scale 0.14 0.14 arvore
            troncoI  = Translate 385 (-10) $ scale 0.1 0.1 tronco
            carroI1  = Translate 0 (-5) $ scale 0.1 0.1 carro1 
            carroI2  = Translate 0 (-5) $ scale 0.1 0.1 carro2
            estradaI = Translate (-5) (-18) $ scale 0.4 0.4 estrada
            rioI     = Translate 0 (-98) $ scale 0.27 0.27 rio
            moedaI   = scale 0.3 0.3 moedaI
            molaI    = Translate 0 (-5) $ scale 1.5 1.5 mola
        
        world <- (estadoInicialGloss (estadoInicial) images j)

        playIO
            window
            bg
            fr
            world
            desenhaEstado
            evento 
            tempo
