{-|
Module      : Tarefa1_2022li1g096
Description : Validação de um mapa
Copyright   : Rafael Correia <a104085@alunos.uminho.pt>
              Afonso Sousa <a104262@alunos.uminho.pt>

Módulo para a realização da Tarefa 1 do projeto de LI1 em 2022/23.
-}
module Tarefa1_2022li1g096 where

import LI12223
import Data.ByteString (elemIndices)
import GHC.Cmm.Dataflow (O)

{- | A função 'mapaValido', a principal deste sistema, é responsável pela verificação de todas as funções que serão apresentadas ao longo
deste programa de modo a testar se um Mapa que fora selecionado é válido ou não de acordo com os parâmetros referidos nas propriedades.

== Algumas características:

* Possui funções recursivas com/sem acumuladores

== Exemplos de utilização:
>>> mapaValido (Mapa 3 [(Rio 0, [Nenhum, Nenhum, Tronco]), (Estrada 2, [Carro, Carro, Nenhum])])
False

>>> mapaValido (Mapa 3 [(Rio 1, [Nenhum, Nenhum, Tronco]), (Estrada 2, [Carro, Carro, Nenhum])])
True

== Para que um 'Mapa' seja válido, é necessário que:
prop> Tenha terrenos com os obstáculos que os caracterizam
prop> Os rios contíguos tenham sentidos opostos
prop> Os troncos nao tenham comprimento superior a 5 unidades
prop> Os carros nao tenham comprimento superior a 3 unidades
prop> Não podem existir mais do que 4 rios contíguos, 5 estradas ou relvas
prop> Tenha pelo menos um obstáculo Nenhum numa linha 
prop> Tenha pelo menos um Tronco num Rio
prop> A largura deve corresponder ao número de obstáculos de uma linha
prop> Um Rio ou Estrada não pode ter velocidade igual a 0, ou seja, não pode estar parado
-}
mapaValido :: Mapa -> Bool
mapaValido (Mapa l ((Rio v, o):xs)) = validarTerreno (Mapa l ((Rio v, o):xs)) && contiRio 0 ((Rio v, o):xs) && isTronco 0 o && conti 0 0 0 ((Rio v, o):xs) && findNenhum ((Rio v, o):xs) && length o == l 
mapaValido (Mapa l ((Estrada v, o):xs)) = validarTerreno (Mapa l ((Estrada v, o):xs)) && conti 0 0 0 ((Estrada v, o):xs) && isCarro 0 o && length o == l
mapaValido (Mapa l ((Relva, o):xs)) = validarTerreno (Mapa l ((Relva, o):xs)) && conti 0 0 0 ((Relva, o):xs) && length o == l

{- | A função 'validarTerreno' tem como objetivo verificar se um determinado terreno é composto por obstáculos característicos do mesmo.

== Característica:

* A função vai ser aplicada a casos específicos

== Exemplos de utilização:

>>> validarTerreno (Mapa 3 ((Rio 1, [Nenhum, Tronco])))
True

>>> validarTerreno (Mapa 2 ((Rio 1, [Carro, Tronco])))
False
-}

validarTerreno :: Mapa -> Bool
validarTerreno (Mapa l list@((Rio v, o):xs)) = all (`elem` [Nenhum,Tronco]) o && findTronco list && v /= 0 && validarTerreno (Mapa l xs) && minNenhum 0 (Relva, o)
validarTerreno (Mapa l ((Estrada v, o):xs)) = all (`elem` [Nenhum,Carro]) o && v /= 0 && validarTerreno (Mapa l xs) && minNenhum 0 (Estrada v, o)                                  
validarTerreno (Mapa l ((Relva, o):xs)) = all (`elem` [Nenhum,Arvore,Mola]) o && validarTerreno (Mapa l xs) && contaMola 0 0 ((Relva, o):xs)
validarTerreno (Mapa l []) = True

{- | A função 'contiRio' é responsável por verificar se rios contíguos apresentam direções opostas.

== Algumas características:

* É recursiva
* É à base de acumuladores que servem para comparar com a velocidade do terreno que se sucede, de modo a haver uma negativa e outra positiva

== Exemplos de utilização:
>>> contiRio 0 [Rio 1, [Nenhum, Tronco, Tronco]), (Rio -1, [Nenhum, Tronco, Tronco])]
True

>>> contiRio 0 [Rio 1, [Nenhum, Tronco, Tronco]), (Rio 1, [Nenhum, Tronco, Tronco])]
False

== Propriedades:
prop> Velocidade positiva indica que o sentido do rio é da esquerda para a direita
prop> Velocidade negativa indica que o sentido do rio é da direita para a esquerda
prop> Apenas se aplica na presença de rios
-}

contiRio :: Int -> [(Terreno, [Obstaculo])]  -> Bool
contiRio _ [] = True
contiRio ve ((Rio v, _):xs) | ve == 0 = contiRio v xs
                            | v > 0 && ve < 0 = contiRio v xs
                            | v < 0 && ve > 0 = contiRio v xs
                            | otherwise = False
contiRio ve ((_,_):xs) = contiRio 0 xs

{- | A função 'isTronco' é responsável por identificar o tamanho de um tronco.

== Algumas características:

* Função recursiva
* Presença de um acumulador

== Exemplos de utilização:
>>> isTronco 0 [Tronco, Tronco, Tronco, Nenhnum]
True

>>> isTronco 0 [Tronco, Tronco, Tronco, Tronco, Tronco, Tronco, Nenhnum]
False

== Propriedades:
prop> Os troncos podem ter no máximo 5 unidades de comprimento

-}

isTronco :: Int -> [Obstaculo] -> Bool
isTronco tr [] | tr > 5 = False
               | otherwise = True
isTronco tr (h:t) | h == Tronco = isTronco (tr+1) t 
                  | h /= Tronco = isTronco 0 t
                  | tr > 5 = False
                  | otherwise = True

{-| A função 'isCarro', à semelhança da 'isTronco', é responsável por identificar o tamanho de um carro.

== Algumas características:

* É uma função recursiva
* É à base de um acumulador  

== Exemplos de utilização:

>>> isCarro 0 [Carro, Carro, Carro, Nenhum]
True

>>> isCarro 0 [Nenhum, Carro, Carro, Carro, Carro]
False

== Propriedades:
prop> Os carros podem ter no máximo 3 unidades de comprimento
-}

isCarro :: Int -> [Obstaculo] -> Bool
isCarro c [] | c > 3 = False
             | otherwise = True
isCarro c (h:t) | h == Carro = isCarro (c+1) t 
                | h /= Carro = isCarro 0 t
                | c > 3 = False
                | otherwise = True

{- | A função 'conti' permite controlar o número de rios, estradas ou relvas consecutivas.

== Algumas características:

* É recursiva
* Tem acumuladores na íntegra
* Utiliza 'case of' como identificador de casos

== Exemplos de utilização:
>>> conti 0 0 0 [(Rio 1,[Nenhum,Tronco,Tronco]),(Rio (-1),[Nenhum,Tronco,Tronco]), (Rio 2,[Tronco,Nenhum,Nenhum]),(Relva,[Nenhum,Arvore,Nenhum]),(Estrada 0,[Carro,Carro,Nenhum])]
True

>>> conti 0 0 0 [(Rio 1,[Nenhum,Tronco,Tronco]),(Rio (-1),[Nenhum,Tronco,Tronco]), (Rio 2,[Tronco,Nenhum,Nenhum]), (Rio 2,[Tronco,Nenhum,Nenhum])]
False

== Propriedades:
prop> Não podem existir mais do que 3 rios e 5 estradas ou relvas contiguas
prop> re é a variável que conta relvas
prop> r é a a variável que conta rios
prop> e é a variável que conta estradas
-}

conti :: Int -> Int -> Int -> [(Terreno, [Obstaculo])] -> Bool
conti re r e ((t, _ ):xs) = case t of
                            (Rio _) -> conti 0 (r + 1) 0 xs
                            Relva -> conti (re + 1) 0 0 xs
                            (Estrada _) -> conti 0 0 (e + 1) xs
conti re r e [] = not (re > 5 || r > 3 || e > 5)

{- | Uma das funções mais simples deste sistema é a 'findNenhum' que verifica se existe pelo menos uma coordenada onde não existam obstáculos.

== Exemplos de utilização:

>>> findNenhum [(Rio 1, [Tronco, Tronco, Nenhum])]
True

>>> findNenhum [(Relva, [Arvore, Arvore, Arvore])]
False
-}

findNenhum :: [(Terreno, [Obstaculo])] -> Bool
findNenhum [] = True
findNenhum ((Rio v, l):xs) | Nenhum `elem` l = findNenhum xs 
                           | otherwise = False

{- A função 'minNenhum' define o mínimo de obstáculos Nenhuns que os terrenos 'Relva' e 'Estrada' devem ter de modo a facilitar a passagem do jogador -}
minNenhum :: Int -> (Terreno, [Obstaculo]) -> Bool
minNenhum n (Relva, (h:t)) | h == Nenhum = minNenhum (n + 1) (Relva, t)
                           | h /= Nenhum = minNenhum n (Relva, t)
minNenhum n (Relva, []) | n > 2 = True
                        | otherwise = False

minNenhum n (Estrada v, (h:t)) | h == Nenhum = minNenhum (n + 1) (Estrada v, t)
                               | h /= Nenhum = minNenhum n (Estrada v, t)
minNenhum n (Estrada v, []) | n > 3 = True
                            | otherwise = False

{- | A função 'findTronco' verifica se existe pelo menos um 'Tronco' aquando da presença de um 'Rio'.

== Exemplos de utilização:

>>> findTronco [(Rio 1, [Nenhum, Nenhum])]
False

>>> findTronco [(Rio 1, [Nenhum, Tronco])]
True
-}

findTronco :: [(Terreno, [Obstaculo])] -> Bool
findTronco ((Rio _, o):xs) | Tronco `elem` o = findTronco xs
                           | otherwise = False  
findTronco [] = True 
findTronco ((_,_):xs) = findTronco xs

{- | Esta função determina o número máximo de molas que pode existir em relvas consecutivas

== Exemplos de utilização:

>>> contaMola 0 0 [(Relva, [Nenhum, Nenhum]), (Relva, [Nenhum, Nenhum]), (Relva, [Nenhum,Mola])]
True

>>> contaMola 0 0 [(Relva, [Nenhum, Mola]), (Relva, [Nenhum,Mola])]
False

== Propriedades
prop> Os contadores devem começar no 0
-}
 
contaMola :: Int -> Int -> [(Terreno,[Obstaculo])] -> Bool 
contaMola r m ((t, o):xs) | Mola `elem` o && t == Relva = contaMola (r + 1) (m + 1) xs
                          | otherwise = contaMola 0 0 xs                           
contaMola r m [] | m <= 1 && r < 6 = True
                 | otherwise = False

