{-|
Module      : Tarefa4_2022li1g096
Description : Determinar se o jogo terminou
Copyright   : Rafael Correia <a104085@alunos.uminho.pt>
              Afonso Sousa <a104262@alunos.uminho.pt>

Módulo para a realização da Tarefa 4 do projeto de LI1 em 2022/23.
-}
module Tarefa4_2022li1g096 where

import LI12223

{-|A função 'jogoTerminou' verifica se um 'Jogador' se encontra ou dentro de um carro, num 'Rio' em 'Nenhum' ou fora do mapa.
Toma auxilio das funções 'inCar', 'inWater' e 'outMap'.

==Exemplos de uso:

>>>jogoTerminou (Jogo (Jogador (0, 1)) (Mapa 3 [(Rio 1, [Nenhum, Tronco, Nenhum])]))
False
>>>jogoTerminou (Jogo (Jogador (0, 0)) (Mapa 3 [(Rio 1, [Nenhum, Tronco, Nenhum])]))
True
-}
jogoTerminou :: Jogo -> Bool
jogoTerminou (Jogo j m) = if outMap m j then True else inCar m j || inWater m j             --ESTRITAMENTE NECESSARIO PARA NAO DAR ERRO DE INDEX TOO LARGE

{-|Quando dado um 'Mapa' e um 'Jogador', a função 'inCar' verifica se o jogador se encontra na mesma posicao de um carro. 

==Exemplos de uso:
>>>inCar (Mapa 3 [(Estrada (-2), [Nenhum, Carro, Nenhum])]) (Jogador (1, 0)) 
True
>>>inCar (Mapa 3 [(Estrada (-2), [Nenhum, Carro, Nenhum])]) (Jogador (0, 0)) 
False
-}
inCar :: Mapa -> Jogador -> Bool
inCar (Mapa _ l) (Jogador (x, y)) = o!!x == Carro
                                where (t, o) = l!!y
{-|Quando dado um 'Mapa' e um 'Jogador', a função 'inWater' verifica se o jogador se encontra num 'Rio' e em 'Nenhum'. 
Toma auxilio da função 'isRio'.

==Exemplos de uso:

>>>inWater (Mapa 3 [(Rio 1, [Tronco, Nenhum, Nenhum])]) (Jogador (1, 0)) 
True
>>>inWater (Mapa 3 [(Relva, [Arvore, Nenhum, Nenhum])]) (Jogador (1, 0)) 
False
-}
inWater :: Mapa -> Jogador -> Bool
inWater (Mapa _ l) (Jogador (x, y)) = isRio t && o!!x == Nenhum
                                where (t, o) = l!!y
{-|A função 'isRio' determina se um 'Terreno' e 'Rio'. Se for 'Rio' devolve True, caso contário devolve False. A velocidade nao importa.
-}
isRio :: Terreno -> Bool
isRio (Rio _) = True
isRio _ = False

{-|A função 'outMap' determina se um 'Jogador' se encontra fora do 'Mapa' recebido. Caso esteja fora do 'Mapa' devolve True.

==Exemplos de uso:

>>>outMap (Mapa 3 [(Rio 2, [Tronco, Tronco, Nenhum])]) (Jogador (0, 1))
True
>>>outMap (Mapa 3 [(Rio 2, [Tronco, Tronco, Nenhum])]) (Jogador (2, 0))
False
-}
outMap :: Mapa -> Jogador -> Bool
outMap (Mapa z l) (Jogador (x, y)) = not((y >= 0 && y < 7)&&(x >= 0&&x < 11))
