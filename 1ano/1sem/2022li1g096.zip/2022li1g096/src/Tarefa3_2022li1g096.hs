{-|
Module      : Tarefa3_2022li1g096
Description : Movimentação do personagem e obstáculos
Copyright   : Rafael Correia <a104085@alunos.uminho.pt>
              Afonso Sousa <a104262@alunos.uminho.pt>

Módulo para a realização da Tarefa 3 do projeto de LI1 em 2022/23.
-}
module Tarefa3_2022li1g096 where

import LI12223
import GHC.Cmm.Dataflow (O)


{- | A função 'animaJogo' é responsável pela animação do jogo.

== Algumas características:

* É composta por funções auxiliares que têm como objetivo apresentar as consequências de uma determinada 'Jogada'

== Exemplos de utilização:
>>> animaJogo (Jogo (Jogador (2,1)) (Mapa 3 [(Rio (-1), [Tronco, Tronco, Nenhum]), (Estrada 1, [Nenhum, Carro, Carro])])) (Move Cima)
Jogo (Jogador (2,2)) (Mapa 3 [(Rio (-1),[Tronco,Nenhum,Tronco]),(Estrada 1,[Carro,Nenhum,Carro])])

>>> animaJogo (Jogo (Jogador (2,1)) (Mapa 3 [(Rio (-1), [Nenhum, Tronco, Tronco]), (Rio 1, [Nenhum, Tronco, Tronco])]))  Parado
Jogo (Jogador (3,1)) (Mapa 3 [(Rio (-1),[Tronco,Tronco,Nenhum]),(Rio 1,[Tronco,Nenhum,Tronco])])


-}
animaJogo :: Jogo -> Jogada -> Jogo
animaJogo (Jogo (Jogador (x,y)) (Mapa l ll)) j = Jogo (posicao (x,y) l ll j) (Mapa l (movimentos ll)) 

animaPlayer :: Jogo -> Jogada -> Jogo
animaPlayer (Jogo (Jogador (x,y)) (Mapa l ll) ) j = Jogo (posicao (x,y) l ll j) (Mapa l ll)

{- | A função 'posicao' está encarregue de mover o jogador consoante a direção, 'Baixo', 'Cima', 'Direita' ou 'Esquerda'. 
Em especial, esta função recebe vários argumentos tais como as coordenadas iniciais do jogador (x,y), a largura do mapa l,
a característica da linha de jogo (ll) e uma 'Direcao'.

== Algumas características:

* Não é uma função recursiva ao contrário das outras que se apresentarão neste sistema
* Incorpora funções auxiliares

== Exemplos de utilização:
>>> posicao (0,0) 3 [(Estrada 1, [Nenhum, Carro, Nenhum]), (Relva, [Nenhum, Arvore, Arvore])] (Move Cima)
Jogador (0,1)

>>> posicao (3,3) 3 [(Relva, [Arvore, Nenhum, Arvore]), (Estrada 1, [Nenhum, Carro, Nenhum])] (Move Cima)
Jogador (3,3)

== O jogador mantém-se na mesma posição se:
 * Estiver no limite superior do mapa e pretender andar uma unidade para cima
 * Estiver no limite lateral esquerdo do mapa e pretender andar uma unidade para a esquerda
 * Estiver no limite lateral direto do mapa e pretender andar uma unidade para a direita
 * Estiver no limite inferior do mapa e pretender andar uma unidade para trás
-}

posicao :: Coordenadas -> Largura -> [(Terreno,[Obstaculo])] -> Jogada -> Jogador

posicao (x, y) l ll (Move d) | d == Cima = if oc!!x == Arvore then Jogador (x, y) else Jogador (x, y-1) 
                             | d == Baixo = if ob!!x == Arvore then Jogador (x, y) else Jogador (x, y+1)
                             | d == Esquerda = if o!!(x-1) == Arvore then Jogador (x, y) else Jogador (x-1, y)
                             | d == Direita = if o!!(x+1) == Arvore then Jogador (x, y) else Jogador (x+1, y)
                             | d == Cima = if y-1 < 0 then Jogador (x, y) else Jogador (x, y - 1)
                             | d == Baixo = if y+1 <= length ll then Jogador (x, y+1) else Jogador (x, y)
                             | d == Esquerda = if x-1 < 0  then Jogador (x, y) else Jogador (x - 1, y)
                             | d == Direita = if x+1 >= l then Jogador (x, y) else Jogador (x + 1, y)
                            where (t1, oc) = ll !! (y-1)
                                  (t2, ob) = ll !! (y+1)
                                  (t3, o)  = ll !! y


posicao (x,y) _ ((Relva, o):t) (Move d) | d == Cima = if o !! (y + 1) == Mola then Jogador (x, y + 3) else Jogador (x, y)   -- 3 -> Poder da Mola. Pode ser alterado consoante o gosto do utilizador
                                        | d == Baixo = if o !! (y - 1) == Mola then Jogador (x, y + 3) else Jogador (x, y)
                                        | d == Esquerda = if o !! (x - 1) == Mola then Jogador (x, y + 3) else Jogador (x, y)
                                        | otherwise = if o !! (x + 1) == Mola then Jogador (x, y + 3) else Jogador (x, y)



{- | A função que se segue surge como um caso especial relativamente à anterior. Para além das situações mencionadas na função anterior,
o jogador também se pode encontrar 'Parado' em certos terrenos. Quando um jogador se encontra 'Parado' em cima de um 'Tronco',
este tem a necessidade de seguir em cima do 'Tronco' consoante a velocidade e o sentido que esta dá ao rio.

== Algumas características:

* É utilizada a partir de definições locais (neste caso 'where')

== Exemplos de utilização:
>>> posicao (2,1) 3 [(Rio (-1), [Nenhum, Tronco, Tronco])] Parado
Jogador (3,1)

>>> posicao (2,1) 3 [(Rio (-1), [Tronco, Tronco, Nenhum]), (Rio 1, [Tronco, Tronco, Nenhum])] Parado
Jogador (2,1)

-}

posicao (x,y) _ ll Parado = posJogador (x,y) (ll !! y)
    where posJogador :: Coordenadas -> (Terreno, [Obstaculo]) -> Jogador
          posJogador (x,y) (Rio v, o) | o !! x == Tronco = Jogador (x+v,y)
                                      | otherwise = Jogador (x,y)  
          posJogador (x,y) _ = Jogador (x,y)

{- | A função 'movimentos' é responsável pelo movimento dos obstáculos consoante a velocidade.

== Algumas características:

* É uma função recursiva
* Incorpora funções auxiliares que se apresentam a seguir ('dir' e 'esq')

== Exemplos de utilização:
>>> movimentos [(Estrada -1, [Carro, Carro, Nenhum])]
[(Estrada -1, [Carro, Nenhum, Carro])]

>>> movimentos [(Rio 1, [Tronco, Nenhum, Tronco])]
[(Rio 1, [Tronco, Tronco, Nenhum])]

== Propriedades:
prop> Quando a velocidade de um dado terreno é superior a 0, os obstáculos movem-se para a direita 'v' posições. Nesta condição, é chamada a função auxiliar dir
prop> Quando a velociade de um dado terreno é inferior a 0, os obstáculos movem-se para a esquerda 'v' posições. Nesta condição, é chamada a função auxiliar esq 

-}

movimentos :: [(Terreno,[Obstaculo])] -> [(Terreno,[Obstaculo])] 
movimentos [] = [] 
movimentos ((Estrada v, o):xs) | v > 0 = (Estrada v, dir o v) : movimentos xs
                               | otherwise = (Estrada v, esq o v) : movimentos xs
movimentos ((Relva, o):xs) = (Relva,o) : movimentos xs
movimentos ((Rio v, o):xs) | v > 0 = (Rio v, dir o v) : movimentos xs
                           | otherwise = (Rio v, esq o v) : movimentos xs

{- | A função 'dir' apresenta o resultado do deslocamento de obstáculos para a direita 
'v' unidades

== Algumas características:

* É uma função auxiliar 
* É uma função recursiva

== Exemplos de utilização:

>>> dir [Nenhum, Nenhum, Tronco, Tronco] 1
[Tronco, Nenhum, Nenhum, Tronco]

>>> dir [Nenhum, Nenhum, Tronco, Tronco] 2
[Tronco, Tronco, Nenhum, Nenhnum]

== Propriedades: 
prop> dir o 0 = o
prop> Velocidade positiva indica o sentido da esquerda para a direita do deslocamento dos obstáculos se esse for o caso
prop> Não se aplicam deslocamentos a obstáculos presentes em relvados
-}

dir :: [Obstaculo] -> Int -> [Obstaculo]
dir o 0 = o
dir o v = dir (last o : init o) (v - 1)

{- | A função 'esq' apresenta o resultado do deslocamento de obstáculos para a esquerda 
'v' vezes.

== Algumas características:

* É uma função auxiliar
* É uma função recursiva

== Exemplos de utilização:

>>> esq [Nenhum, Nenhum, Tronco, Tronco] -1
[Nenhum, Tronco, Tronco, Nenhum]

>>> esq [Nenhum, Nenhum, Tronco, Tronco] -2
[Tronco, Tronco, Nenhum, Nenhnum]

== Propriedade: 
prop> esq o 0 = o
prop> Velocidade negativa indica o sentido da direita para a esquerda do deslocamento dos obstáculos se esse for o caso
prop> Nao se aplicam deslocamentos a obstáculos presentes em relvados
-}

esq :: [Obstaculo] -> Int -> [Obstaculo]
esq o 0 = o
esq o v = esq (tail o ++ [head o] ) (v + 1)

contaMoedas :: Int -> Coordenadas -> [(Terreno,[Obstaculo])] -> Jogada -> Int
contaMoedas n (x, y) [(_, o)] (Move d) | d == Cima = if o !! (y + 1) == Moeda then n + 2 else n
                                       | d == Baixo = if o !! (y - 1) == Moeda then n + 2 else n
                                       | d == Esquerda = if o !! (x - 1) == Moeda then n + 2 else n
                                       | otherwise = if o !! (x + 1) == Moeda then n + 2 else n

atualizaScore :: Int -> Jogo -> Jogada -> Int
atualizaScore score (Jogo (Jogador (x, y)) (Mapa lar ll)) (Move d) | d == Cima = if oc!!x == Arvore then score else score+1
                                                                   | d == Baixo = if ob!!x == Arvore then score else score-1
                                                                   | d == Cima = if y-1 < 0 then score else score+1
                                                                   | d == Baixo = if y+1 <= length ll then score else score-1
                                                                   where (t1, oc) = ll !! (y-1)
                                                                         (t2, ob) = ll !! (y+1)

