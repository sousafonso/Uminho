module Tarefa4_2022li1g096_Spec where

import LI12223
import Tarefa4_2022li1g096
import Test.HUnit


testsT4 :: Test
testsT4 = TestLabel "Testes Tarefa 4" $ test [
    "Teste 1" ~: True ~=? jogoTerminou (Jogo (Jogador (1, 1)) (Mapa 3 [(Relva, [Nenhum, Arvore, Nenhum]), (Rio (-1), [Tronco, Nenhum, Tronco]), (Estrada 2, [Carro, Carro, Nenhum])])),
    "Teste 2" ~: False ~=? jogoTerminou (Jogo (Jogador (0, 0)) (Mapa 3 [(Relva, [Nenhum, Arvore, Nenhum]), (Rio (-1), [Tronco, Nenhum, Tronco]), (Estrada 2, [Carro, Carro, Nenhum])])),
    "Teste 3" ~: True ~=? jogoTerminou (Jogo (Jogador (0, 2)) (Mapa 3 [(Relva, [Nenhum, Arvore, Nenhum]), (Rio (-1), [Tronco, Nenhum, Tronco]), (Estrada 2, [Carro, Carro, Nenhum])])),
    "Teste 4" ~: False ~=? jogoTerminou (Jogo (Jogador (2 ,1)) (Mapa 3 [(Relva, [Nenhum, Arvore, Nenhum]), (Rio (-1), [Tronco, Nenhum, Tronco]), (Estrada 2, [Carro, Carro, Nenhum])])),
    "Teste 5" ~: False ~=? jogoTerminou (Jogo (Jogador (2, 2)) (Mapa 3 [(Relva, [Nenhum, Arvore, Nenhum]), (Rio (-1), [Tronco, Nenhum, Tronco]), (Estrada 2, [Carro, Carro, Nenhum])]))
    ]
