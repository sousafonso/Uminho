module Tarefa1_2022li1g096_Spec where

import LI12223
import Tarefa1_2022li1g096
import Test.HUnit


testsT1 :: Test
testsT1 = TestLabel "Testes Tarefa 1" $ test [
    "Teste 1" ~: True ~=? mapaValido (Mapa 3 [(Rio 1,[Nenhum,Tronco,Tronco]),(Rio (-1),[Nenhum,Tronco,Tronco]), (Rio 2,[Tronco,Nenhum,Nenhum]),(Relva,[Nenhum,Arvore,Nenhum]),(Estrada 2,[Carro,Carro,Nenhum])]), 
    "Teste 2" ~: False ~=? mapaValido (Mapa 4 [(Rio 1,[Nenhum,Tronco,Tronco]),(Rio (-1),[Nenhum,Tronco,Tronco]), (Rio 2,[Tronco,Nenhum,Nenhum]),(Relva,[Nenhum,Arvore,Nenhum]),(Estrada 0,[Carro,Carro,Nenhum])]),
    "Teste 3" ~: False ~=? mapaValido (Mapa 2 [(Rio 1,[Tronco,Tronco]),(Rio 1,[Nenhum,Tronco]), (Rio 2,[Tronco,Nenhum]),(Relva,[Nenhum,Arvore]),(Estrada 3,[Carro,Nenhum])]),
    "Teste 4" ~: True ~=? mapaValido (Mapa 4 [(Rio 1,[Nenhum,Tronco,Tronco,Nenhum]),(Rio (-1),[Nenhum,Tronco,Tronco,Nenhum]), (Rio 2,[Tronco,Nenhum,Nenhum,Tronco]),(Relva,[Nenhum,Arvore,Nenhum,Arvore]),(Estrada 0,[Carro,Carro,Nenhum,Carro])]),
    "Teste 5" ~: True ~=? mapaValido (Mapa 3 [(Estrada 1,[Nenhum,Carro,Carro]),(Rio (-1),[Nenhum,Tronco,Tronco]), (Relva,[Arvore,Nenhum,Nenhum]),(Relva,[Nenhum,Arvore,Nenhum]),(Estrada 5,[Carro,Carro,Nenhum])]),
    "Teste 6" ~: False ~=? mapaValido (Mapa 3 [(Rio 1,[Nenhum,Tronco,Tronco]),(Rio (-1),[Nenhum,Tronco,Tronco]), (Rio 2,[Tronco,Nenhum,Nenhum]),(Rio (-2),[Nenhum,Tronco,Nenhum]),(Rio 1,[Tronco,Tronco,Nenhum])])
    ]
