module Tarefa3_2022li1g096_Spec where

import LI12223
import Tarefa3_2022li1g096
import Test.HUnit

testsT3 :: Test
testsT3 = TestLabel "Testes Tarefa 3" $ test [
    "Teste 1" ~: Jogo (Jogador (2,2)) (Mapa 3 [(Rio (-1),[Tronco,Nenhum,Tronco]),(Estrada 1,[Carro,Nenhum,Carro])]) ~=? animaJogo (Jogo (Jogador (2,1)) (Mapa 3 [(Rio (-1), [Tronco, Tronco, Nenhum]), (Estrada 1, [Nenhum, Carro, Carro])])) (Move Cima),
    "Teste 2" ~: Jogo (Jogador (3,1)) (Mapa 3 [(Rio (-1),[Tronco,Tronco,Nenhum]),(Rio 1,[Tronco,Nenhum,Tronco])]) ~=? animaJogo (Jogo (Jogador (2,1)) (Mapa 3 [(Rio (-1), [Nenhum, Tronco, Tronco]), (Rio 1, [Nenhum, Tronco, Tronco])]))  Parado,
    "Teste 3" ~: Jogo (Jogador (1,0)) (Mapa 2 [(Rio (-1),[Nenhum,Tronco]),(Estrada 1,[Carro,Nenhum])]) ~=? animaJogo (Jogo (Jogador (1,1)) (Mapa 2 [(Rio (-1), [ Tronco, Nenhum]), (Estrada 1, [Nenhum, Carro])])) (Move Baixo),
    "Teste 4" ~: Jogo (Jogador (1,0)) (Mapa 4 [(Rio (-1),[Nenhum,Tronco,Nenhum,Tronco]),(Rio 1,[Nenhum,Nenhum,Tronco,Tronco])]) ~=? animaJogo (Jogo (Jogador (1,1)) (Mapa 4 [(Rio (-1), [ Tronco, Nenhum, Tronco, Nenhum]), (Rio 1, [Nenhum, Tronco, Tronco, Nenhum])])) (Move Baixo),
    "Teste 5" ~: Jogo (Jogador (1,0)) (Mapa 4 [(Rio (-1),[Nenhum,Tronco,Nenhum,Tronco]),(Rio 1,[Nenhum,Nenhum,Tronco,Tronco])]) ~=? animaJogo (Jogo (Jogador (1,0)) (Mapa 4 [(Rio (-1), [ Tronco, Nenhum, Tronco, Nenhum]), (Rio 1, [Nenhum, Tronco, Tronco, Nenhum])])) (Move Baixo),
    "Teste 6" ~: Jogo (Jogador (1,0)) (Mapa 4 [(Relva,[Arvore,Nenhum,Arvore,Nenhum]),(Rio 1,[Nenhum,Nenhum,Tronco,Tronco])]) ~=? animaJogo (Jogo (Jogador (1,0)) (Mapa 4 [(Relva, [ Arvore, Nenhum, Arvore, Nenhum]), (Rio 1, [Nenhum, Tronco, Tronco, Nenhum])])) (Move Esquerda)
    ]
